Overview
--------

This is a Python package skeleton that demonstrates what directory layout to use and which files are necessary.


Installation
------------

``pip install git+https://github.com/ralienpp/python-package-skeleton.git``



Example
-------
::

    from acmepack.core import Nucleus
    n = Nucleus()
    print n.test(3)
    
    
