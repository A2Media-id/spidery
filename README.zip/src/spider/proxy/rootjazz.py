#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import logging
import re
import traceback

from spider import ProxyEngine, ProxyData


class Engine(ProxyEngine):
    _me = __file__
    urls = ['http://rootjazz.com/proxies/proxies']

    def __init__(self, **kwargs):
        super(Engine, self).__init__(**kwargs)


if __name__ == '__main__':
    eng = Engine()
    for proxy in eng.search():
        print(proxy)
