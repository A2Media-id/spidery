import logging

from spidery.spider import BaseCrawl

log = logging.getLogger('demo')


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG,
                        format='%(asctime)s %(name)12s %(levelname)5s %(threadName)s - %(message)s',
                        datefmt="%a %d %H:%M:%S")
    log.info('Initializing nucleus with no arguments')
    n = BaseCrawl()

    log.info('That is all, folks!')
