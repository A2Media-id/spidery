import setuptools


LONG_DESC = open("README.md", "r", encoding="utf-8").read()

setuptools.setup(
    name='spidery',
    version='0.0.1',
    long_description=LONG_DESC,
    description='Python package skeleton',
    author='Akbar Romadhoni',
    author_email='a.railean@dekart.com',
    keywords=['python', 'tutorial'],
    license='MIT',
    classifiers=[
        'Programming Language :: Python',
        'Operating System :: OS Independent',
        'Natural Language :: English',
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Intended Audience :: System Administrators',
        'License :: OSI Approved :: BSD License'
    ],
    # provide your external dependencies here as a list of strings
    install_requires=[
        "requests",
        "requests[socks]",
        "BeautifulSoup4",
        "ipaddress>=1.0.23",
        "pyquery",
        "lxml"
    ],
    package_dir={"": "src"},
    packages = setuptools.find_packages(where='src'),
    python_requires=">=3.6",
)
