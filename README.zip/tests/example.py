from unittest import TestCase


from spidery.spider import BaseCrawl

class TestJoke(TestCase):
    def test_is_string(self):
        s = BaseCrawl()
        self.assertTrue(isinstance(s, BaseCrawl))
